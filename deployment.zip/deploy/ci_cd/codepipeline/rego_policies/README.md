# Rego Policies

---

See [here](https://www.openpolicyagent.org/docs/latest/policy-language/) for details on how to author