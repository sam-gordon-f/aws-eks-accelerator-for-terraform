## Networking

### Networking Policy

Handled via Kubernetes network policy

## Security

### Cluster Access

Recommended to keep set to private (default in the wrapper)

### Cluster Roles

There are 2 "roles" that are bootstrapped via the proserve wrapper

a. editor
b. reader

## Insights

### Logging

### Metrics